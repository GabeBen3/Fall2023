{
    {
    county = Merced
        { city = Merced
            { latitude = 
            }
        }

        { city = Los Banos
            { 
                longitude = 
                latitude = 
            }
        }
    }

    {
    county = Mariposa
        { city = Mariposa
            { latitude = 
                longitude = 
            }
        }
    }

}


Tree(nodeId, parent)
1 null
2   1
3   1
4   2
5   2
6   2
7   3

            1
        2       3
4   5   6      7

Graph
Edges(source, sink)
1   4
1   2
2   3
3   4

1------------------4
|                  |
|                  |
|                  |
2------------------3

