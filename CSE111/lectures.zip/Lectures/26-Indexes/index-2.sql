--SQLite

.eqp on
.timer on
.output out.res.index


select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;

select l_orderkey
from lineitem
where l_quantity = 10;
