--SQLite

.eqp on
.timer on
.output out.res.index


select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;

select l_orderkey
from lineitem;
